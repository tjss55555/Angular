import {Injectable} from '@angular/core'
import {HttpClient} from '@angular/common/http'
import {Observable} from 'rxjs'


export interface item{
    name:string,
    description:string,
    url:string,
    html:string,
    markdown:string
}

@Injectable({
    providedIn:'root'
})
export class AppService{


    private url="https://www.techiediaries.com/api/data.json"

    constructor(private http:HttpClient){

    }

    fetchData():Observable<item[]>{
        return <Observable<item[]>>this.http.get(this.url)
    }
}