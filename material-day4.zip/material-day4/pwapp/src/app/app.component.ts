import { Component } from '@angular/core';
import {AppService} from './api.service'
import {item} from './api.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'pwapp';
  items:Array<item>

  constructor(private apiService:AppService){

  }

  ngOnInit(){
    this.apiService.fetchData().subscribe((data:Array<item>)=>this.items=data)
  }
}
