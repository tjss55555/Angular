import {Component,Input,EventEmitter,Output} from '@angular/core'
import {IEvent} from '../shared/event.model'

@Component({
    selector:'event-thumbnail',
    template:`
            <div [routerLink]="['/events',event.id]" class="well hoverwell thumbnail">
                    <h2>{{event?.name|uppercase}}</h2>
                    <div>Date:{{event?.date|date:'y/M/d'}}</div>
                    <div [ngStyle]="applyStyle()" [ngSwitch]="event?.time">
                        Time:{{event?.time}}
                        <span *ngSwitchCase="'8:00 am'">[Early start]</span>
                        <span *ngSwitchCase="'9:00 am'">[Normal start]</span>
                        <span *ngSwitchDefault>[Late start]</span>
                    </div>
                    <div>Price:{{event?.price|currency:'EUR'}}</div>
                    <div *ngIf="event?.location">
                        <span>Location:{{event?.location?.address}}</span>
                        <span>{{event?.location?.city}},{{event?.location?.country}}</span>
                    </div>
                    <div *ngIf="event?.onlineUrl">OnlineUrl:{{event?.onlineUrl}}</div>
            <div>

            <div *ngIf="status; else elseblock">Welcome to Angular</div>
            <ng-template #elseblock>Sorry no welcome message</ng-template>

            <div>{{3.141592|number:'3.1-3'}}</div>
            <div>{{0.123456|percent:'2.1-2'}}</div>        
            <div>{{[1,2,3,4,5,6]|slice:2}}</div>    
    `,
    styles:[
        `
        .thumbnail{min-height:200px}
        .redclass{color:red}
        .greenclass{color:green}
        `
    ]
})
export class EventThumbnailComponent{
    @Input() event:IEvent

    status=false

    pickupCssClass(){
        if(this.event.time==='10:00 am'){
            return ['redclass']
        }else{
            return ['greenclass']
        }
    }

    applyStyle(){
        if(this.event.time==='10:00 am'){
            return {color:'red','font-weight':'bold'}
        }else{
            return {color:'green'}
        }
    }
}