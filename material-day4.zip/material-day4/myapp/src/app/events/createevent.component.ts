import {Component} from '@angular/core'
import {Router} from '@angular/router'
import {EventService} from '../shared/event.service'


@Component({
   templateUrl:'./createevent.html'
})
export class CreateEventComponent{

    constructor(private route:Router,private eventService:EventService){

    }

    cancelMe(){
        this.route.navigate(['events'])
    }

    saveEvent(formValues){
        this.eventService.addEvent(formValues)
        this.route.navigate(['events'])
    }
}