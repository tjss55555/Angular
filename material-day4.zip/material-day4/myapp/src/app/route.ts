import {Routes} from '@angular/router'
import {EventListComponent} from './events/event.list.component'
import {EventDetComponent} from './events/eventdetails.component'
import {CreateEventComponent} from './events/createevent.component'
import {Error404Component} from './events/error.component'
import {EventRouteActService} from './shared/eventrouteact.service'

export const appRoutes:Routes=[
    {path:'events/new',component:CreateEventComponent},
    {path:'events',component:EventListComponent},
    {path:'events/:id',component:EventDetComponent,canActivate:[EventRouteActService]},
    {path:'404',component:Error404Component},
    {path:'user',loadChildren:'src/app/user/user.module#UserModule'}

]