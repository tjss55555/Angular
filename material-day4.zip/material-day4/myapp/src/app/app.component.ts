import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
 /* template:`
      <nav-bar></nav-bar>
      <router-outlet></router-outlet>
  `*/
/*  template:`

      <async-pipe></async-pipe>
  
  `*/
  template:`
    <emp-det></emp-det>
  
  `
  
})
export class AppComponent {
 
}
