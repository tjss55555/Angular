import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router'
import {FormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http'

import { AppComponent } from './app.component';
import {EventListComponent,EventThumbnailComponent,EventDetComponent,
 CreateEventComponent, Error404Component,SessionListComponent} from './events/index'

import {EventService,EventRouteActService,UserService,DurationPipe} from './shared/index'

import {EmpComponent} from './emp/emp.component'
import {EmpService} from './emp/emp.service'
import {AsyncPipeComponent} from './asyncpipe/asyncpipe.component'

import {appRoutes} from './route'
import {NavBarComponent} from './nav/navbar.component'


@NgModule({
  declarations: [
    AppComponent,EventListComponent,EventThumbnailComponent,NavBarComponent,EventDetComponent,
    CreateEventComponent,Error404Component,SessionListComponent,AsyncPipeComponent,DurationPipe,
    EmpComponent
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(appRoutes),HttpClientModule
  ],
  providers: [EventService,UserService,EmpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
