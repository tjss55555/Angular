import {Component} from '@angular/core'
import {FormGroup,FormControl,Validators} from '@angular/forms'
import {UserService} from '../shared/user.service'


@Component({
   templateUrl:'./profilepage.html',
   styles:[`
        
        em{color:red;float:right}
   `]
})
export class ProfileComponent{

    profileForm:FormGroup

    firstName:FormControl
    lastName:FormControl

    constructor(private userServ:UserService){

    }

    ngOnInit(){
        this.firstName=new FormControl(this.userServ.currentUser.firstName,[Validators.required,
                                                                            Validators.pattern('[a-zA-Z].*')])
        this.lastName=new FormControl(this.userServ.currentUser.lastName,Validators.required)

        this.profileForm=new FormGroup({
            firstName:this.firstName,
            lastName:this.lastName
        })
    }

    invokeService(formValues){
        this.userServ.updateUser(formValues.firstName,formValues.lastName)   
    }

    //return true if it is valid and untouched
    validateFirstName(){
        return this.firstName.valid || this.firstName.untouched
    }

 //return true if it is valid and untouched
    validateLastName(){
        return this.lastName.valid || this.lastName.untouched
    }
}