import {Component} from '@angular/core'
import {UserService} from '../shared/user.service'
import {Router} from '@angular/router'


@Component({
    templateUrl:'./loginpage.html',
    styles:[`
    
        em{color:red;float:right}
    `]
})
export class LoginComponent{

   
    constructor(private userServ:UserService,private router:Router){

    }

    invokeService(formValues){
        this.userServ.validateUser(formValues.userName,formValues.password)
        this.router.navigate(['events'])
    }
}