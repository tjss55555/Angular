import {Injectable} from '@angular/core'
import {HttpClient,HttpHeaders,HttpParams} from '@angular/common/http'
import {Observable} from 'rxjs'

@Injectable()
export class EmpService{
   
   private url="http://localhost:8080/demo1/webapi/empservice/json/employees"

   private urlpost="http://localhost:8080/demo2/webapi/tasks"

   constructor(private http:HttpClient){

   }
   giveEmployees():Observable<any>{
       return this.http.get(this.url)
   }

   addData():Observable<any>{
       let httpHeaders=new HttpHeaders({'Content-Type':'application/x-www-form-urlencoded;charset=utf-8'})
       let httpParams=new HttpParams().set('id','T5').set('description',"Fifth Task")
       return this.http.post(this.urlpost,httpParams,{headers:httpHeaders,observe:"response"})
   }

}