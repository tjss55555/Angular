import {Component} from '@angular/core'
import {EmpService} from './emp.service' 
import {IEmp} from './emp.model'

@Component({
    selector:'emp-det',
    templateUrl:'./empdet.html'
})
export class EmpComponent{

    employees:IEmp[]
    res:any

    constructor(private empService:EmpService){
       // this.empService.giveEmployees().subscribe(employees=>this.employees=employees)
        this.empService.addData().subscribe(res=>this.res=res)   
    }
}