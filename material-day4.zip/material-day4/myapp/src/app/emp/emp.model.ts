export interface IEmp{
    employeeId:string,
    employeeName:string,
    designation:string
}