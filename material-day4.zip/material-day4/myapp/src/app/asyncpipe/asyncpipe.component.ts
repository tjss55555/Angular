import {Component} from '@angular/core'

@Component({
    selector:'async-pipe',
    template:`
            <div>
                <p>Output will be flashed after 3 seconds {{name|async}}</p>
                
            </div>
    
    `
})

export class AsyncPipeComponent{
    name:Promise<any>

    constructor(){
        this.name=this.getName()
    }

    getName(){
        return new Promise((resolve,reject)=>{
            setTimeout(()=>resolve("Pravin"),3000)
        })
    }
}