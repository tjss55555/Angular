import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router'
import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import {EventListComponent,EventThumbnailComponent,EventDetComponent,
 CreateEventComponent, Error404Component} from './events/index'

import {EventService,EventRouteActService,UserService} from './shared/index'


import {appRoutes} from './route'
import {NavBarComponent} from './nav/navbar.component'


@NgModule({
  declarations: [
    AppComponent,EventListComponent,EventThumbnailComponent,NavBarComponent,EventDetComponent,
    CreateEventComponent,Error404Component
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(appRoutes)
  ],
  providers: [EventService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
