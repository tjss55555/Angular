import {Component} from '@angular/core'
import {Router} from '@angular/router'

@Component({
   templateUrl:'./createevent.html'
})
export class CreateEventComponent{

    constructor(private route:Router){

    }

    cancelMe(){
        this.route.navigate(['events'])
    }
}