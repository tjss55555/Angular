import {Component} from '@angular/core'

@Component({
    template:`
            <div>
                <h2>Error occurred</h2>
            </div>
    
    `,
    styles:[
        `
        h2{color:red}
        `
    ]
})
export class Error404Component{

}