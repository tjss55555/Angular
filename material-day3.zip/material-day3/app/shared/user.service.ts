import {Injectable} from '@angular/core'
import {IUser} from './user.model'

@Injectable()
export class UserService{

    currentUser:IUser

    validateUser(userName:string,password:string){
        //hit the restful service
        //all users are valid user therefore we are getting some data in currentUser var
        this.currentUser={
            id:1,
            firstName:'Seema',
            lastName:'Agarwal',
            userName:userName
        }
       
    }

    isAuthenticated(){
        return !!this.currentUser
    }

    updateUser(fname:string,lname:string){
        this.currentUser.firstName=fname
        this.currentUser.lastName=lname
        //hit the restful service and send the data of currentuser
    }
}