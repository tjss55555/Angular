import {Component} from '@angular/core'
import {UserService} from '../shared/user.service'

@Component({
    selector:'nav-bar',
    templateUrl:'./navbar.html'
})
export class NavBarComponent{
    
    constructor(private userService:UserService){

    }
}