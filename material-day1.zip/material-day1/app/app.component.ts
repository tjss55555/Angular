import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template:`
      <event-list></event-list>
  `
  
})
export class AppComponent {
  title = 'myapp';
}
