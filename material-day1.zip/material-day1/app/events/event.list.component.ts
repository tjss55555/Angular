import {Component} from '@angular/core'

@Component({
    selector:'event-list',
    template:`
            <div>
                <h1 [innerText]="title"></h1>
                <hr/>
                <div>
                    <h2>{{event.name}}</h2>
                    <div>Date:{{event.date}}</div>
                    <div>Time:{{event.time}}</div>
                    <div>Price:{{event.price}}</div>
                    <div>
                        <span>Location:{{event.location.address}}</span>
                        <span>{{event.location.city}},{{event.location.country}}</span>
                    </div>
                <div>
                <button (click)="save()">Click Me</button>
                <br/>
                <input type="text" [(ngModel)]="prdName"/>

                <br/>
                <span>Product Name is {{prdName}}</span>
                
            </div>
    
    `,
    styles:[
        `
        h2{color:red}
        `
    ]
})
export class EventListComponent{
    title="Upcoming Angular Events"

    prdName="Monitor"
    
    event={
        id:1,
        name:'Angular Connect',
        date:'01/01/2020',
        time:'8:00 am',
        price:456,
        location:{
            address:'Abc Street',
            city:'Mumbai',
            country:'India'
        }
 
    }

    save():void{
        console.log("Inside save...")
    }
}