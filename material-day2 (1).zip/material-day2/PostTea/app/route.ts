import {Routes} from '@angular/router'
import {EventListComponent} from './events/event.list.component'
import {EventDetComponent} from './events/eventdetails.component'
import {CreateEventComponent} from './events/createevent.component'

export const appRoutes:Routes=[
    {path:'events/new',component:CreateEventComponent},
    {path:'events',component:EventListComponent},
    {path:'events/:id',component:EventDetComponent}
]