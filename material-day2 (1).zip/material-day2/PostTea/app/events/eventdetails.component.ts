import {Component} from '@angular/core'
import {EventService} from '../shared/event.service'
import {ActivatedRoute} from '@angular/router'

@Component({
    selector:'event-det',
    templateUrl:'./eventdet.html',
    styles:[`
        .event-image{height:100px}
    `]
})
export class EventDetComponent{
    event:any

    constructor(private eventService:EventService,private actRoute:ActivatedRoute){
        this.event=eventService.getEvent(+actRoute.snapshot.params['id'])
    }


}