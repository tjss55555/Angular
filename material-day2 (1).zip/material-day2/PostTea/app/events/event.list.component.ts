import {Component} from '@angular/core'
import {EventService} from '../shared/event.service'

@Component({
    selector:'event-list',
    template:`
            <div>
                <h1 [innerText]="title"></h1>
                <hr/>

                <div *ngFor="let event of events" class="col-md-5">
                    <event-thumbnail [event]="event"></event-thumbnail>
                </div>
            </div>
    `,
    providers:[]
})
export class EventListComponent{
    title="Upcoming Angular Events"
    events:any[]

    constructor(private eventService:EventService){
        this.events=eventService.getEvents()
    }
    


}