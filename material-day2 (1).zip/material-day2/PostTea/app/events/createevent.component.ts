import {Component} from '@angular/core'
import {Router} from '@angular/router'

@Component({
    template:`
        <div>
            <h1>New Event</h1>
            <h3>[New Event form will go here]</h3>

            <br/>
            <br/>
            <button>Save</button>
            <button (click)="cancelMe()">Cancel</button>
        </div>
    
    
    `
})
export class CreateEventComponent{

    constructor(private route:Router){

    }

    cancelMe(){
        this.route.navigate(['events'])
    }
}