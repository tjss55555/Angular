import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {EventListComponent} from './events/event.list.component'
import {FormsModule} from '@angular/forms'
import {EventThumbnailComponent} from './events/event.thumbnail.component'
import {NavBarComponent} from './nav/navbar.component'
import {EventService} from './shared/event.service'
import {EventDetComponent} from './events/eventdetails.component'
import {RouterModule} from '@angular/router'
import {appRoutes} from './route'
import {CreateEventComponent} from './events/createevent.component'

@NgModule({
  declarations: [
    AppComponent,EventListComponent,EventThumbnailComponent,NavBarComponent,EventDetComponent,
    CreateEventComponent
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(appRoutes)
  ],
  providers: [EventService],
  bootstrap: [AppComponent]
})
export class AppModule { }
