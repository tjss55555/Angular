import {Component} from '@angular/core'

@Component({
    selector:'event-list',
    template:`
            <div>
                <h1 [innerText]="title"></h1>
                <hr/>
                <event-thumbnail #thumbnail (eventClick)="showCity($event)" [event]="event"></event-thumbnail>
                <button (click)="thumbnail.display()">CallDisplay</button>
            </div>

            
    
    `
})
export class EventListComponent{
    title="Upcoming Angular Events"

    
    event={
        id:1,
        name:'Angular Connect',
        date:'01/01/2020',
        time:'8:00 am',
        price:456,
        location:{
            address:'Abc Street',
            city:'Mumbai',
            country:'India'
        }
 
    }

    showCity(cityName){
        console.log("name of the city is "+cityName)
    }

}